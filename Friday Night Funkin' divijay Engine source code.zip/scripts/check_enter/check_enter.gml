function check_enter() {
    
    // Проверяем, существует ли глобальная переменная
    if (!variable_global_exists("enter_locked")) {
        global.enter_locked = false;
    }

    // Если нажат Enter и перехода еще не было
    if (keyboard_check_pressed(vk_enter) && !global.enter_locked) {
        global.enter_locked = true; // Ставим блок
        
        // Включаем звук подтверждения!
        // ВАЖНО: замени "snd_confirm" на точное имя твоего звукового файла в GameMaker
        audio_play_sound(snd_confirm, 1, false); 
        
        room_goto(r_menu);          // Переходим
    }
    
}