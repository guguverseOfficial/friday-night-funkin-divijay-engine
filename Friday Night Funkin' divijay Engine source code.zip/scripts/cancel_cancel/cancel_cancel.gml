function cancel_cancel(){
    audio_play_sound(snd_cancel, 1, false);
    room_goto(r_menu);
}