/// @desc Ловушка Балди: музыка, переход и вылет через 7 секунд
function scr_baldi_trap() {
    
    // 1. Включаем музыку "Намби намби"
    audio_play_sound(snd_nambir, 1, false);
    
    // 2. Переходим в комнату с Балди
    room_goto(r_baldi);
    
    // 3. Запускаем таймер прямо здесь (7 секунд = 7000 миллисекунд)
    // Эта функция вызовет game_end через 7 секунд
    call_later(7, time_source_units_seconds, function() {
        game_end(); 
    });
}