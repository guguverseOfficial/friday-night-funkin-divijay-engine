/// @desc Загружает тестовый мод по умолчанию
function load_default_mod() {
    
    // Путь к тестовому моду
    var _mod_path = "mods/TestMod/";
    
    // 1. Читаем чарт (song1.json)
    var _chart_path = _mod_path + "charts/song1.json";
    
    if (file_exists(_chart_path)) {
        var _file = file_text_open_read(_chart_path);
        var _json_string = "";
        while (!file_text_eof(_file)) {
            _json_string += file_text_read_string(_file);
            file_text_readln(_file);
        }
        file_text_close(_file);

        // Парсим JSON и сохраняем ноты
        var _data = json_parse(_json_string);
        global.mod_notes = _data.notes;
        
        show_debug_message("✅ Тестовый чарт загружен! Нот: " + string(array_length(global.mod_notes)));
    } else {
        show_debug_message("❌ ОШИБКА: Файл song1.json не найден в TestMod!");
    }

    // 2. Загружаем музыку (Inst.ogg)
    var _audio_path = _mod_path + "audio/Inst.ogg";
    
    if (file_exists(_audio_path)) {
        global.mod_music = audio_create_stream(_audio_path);
        show_debug_message("✅ Музыка TestMod загружена!");
    } else {
        show_debug_message("❌ ОШИБКА: Музыка Inst.ogg не найдена в TestMod!");
    }
}