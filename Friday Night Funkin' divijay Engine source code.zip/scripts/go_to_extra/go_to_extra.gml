function go_to_extra() {
    audio_play_sound(snd_confirm, 1, false);
    room_goto(r_extra);
}